class Forca {
  constructor(palavraDesconhecida){
      this.palavraDesconhecida = palavraDesconhecida;
      this.letrasChutadas = [];
      this.vidas = 6;
      this.palavra = [];
      this.estado = "aguardando chute";
  }
  
  inicializaPalavra(){
      for(let i = 0; i < this.palavraDesconhecida.length; i++)
          this.palavra[i] = "_";
  }
  
  verificaSeEncontrouPalavra(){ // Verifica se ainda existem espaços em branco no Array "palavra" a ser descoberto
      for(let i = 0; i < this.palavra.length; i++){
          if(this.palavra[i] == "_") 
              return "aindaFaltaLetra"; 
      }
      return "completou";
  }
  
  verificaVidas(){ // Verifica as vidas e a situação do Array "palavra" - se contém ou não underscores
      if(this.vidas < 1 && this.verificaSeEncontrouPalavra() == "aindaFaltaLetra")
          this.estado = "perdeu";
      else if(this.vidas > 0 && this.verificaSeEncontrouPalavra() == "completou")
          this.estado = "ganhou";
      else
          this.estado = "aguardando chute";
  }
  
  buscaLetraRepetida(letra1){ // Verifica se chutou ou não uma letra
      if(this.letrasChutadas.length == 0){
          this.letrasChutadas.push(letra1);
          return 'naoChutou';
      }
      
      for(let i = 0; i < this.letrasChutadas.length; i++){
          if(letra1 == this.letrasChutadas[i]){
              return 'jaChutou';
          }
      }
      this.letrasChutadas.push(letra1);
      return 'naoChutou';
  }
  
  buscaLetraNaPalavraDesconhecida(letra2){ // Verifica se a letra chutada está contida na string passada no método chutar()
      let cont = 0;
      for(let i  = 0; i < this.palavraDesconhecida.length; i++){
        if(letra2 == this.palavraDesconhecida.charAt(i)){
            this.palavra[i] = letra2;
            cont++;
        }
      }
      if(cont == 0)
          this.vidas--;
  }
  chutar(letra) {
       if(this.palavra.length == 0)
        this.inicializaPalavra();
    if(letra.length == 1 && this.buscaLetraRepetida(letra) == 'naoChutou'){ // Verifica se "letra" tem um caractere e se é uma letra repetida
        this.buscaLetraNaPalavraDesconhecida(letra);
        this.verificaVidas();
        
    }
  }

  buscarEstado() { 
        return this.estado;
    } // Possiveis valores: "perdeu", "aguardando chute" ou "ganhou"

  buscarDadosDoJogo() {
      return {
          letrasChutadas:this.letrasChutadas, // Deve conter todas as letras chutadas
          vida:this.vidas, // Quantidade de vidas restantes
          palavra:this.palavra // Deve ser um array com as letras que já foram acertadas ou o valor "_" para as letras não identificadas
      }
  }
}

module.exports = Forca;